module.exports = () => {
  require('./Customer');
};
